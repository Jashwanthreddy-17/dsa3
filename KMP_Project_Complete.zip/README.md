# KMP Search Engine

KMP Search Engine is a compact full-stack Java project for finding exact text patterns across manual input and multiple uploaded text files. It pairs a responsive browser dashboard with a Java backend that implements the Knuth–Morris–Pratt (KMP) algorithm directly—no frameworks, libraries, database, or internet connection required.

## Why this project

Searching for a pattern by repeatedly moving back through the text can redo work after a partial match fails. KMP avoids that repetition. It first builds an LPS (Longest Proper Prefix which is also Suffix) table for the pattern, then uses it to continue from the correct position instead of restarting unnecessarily.

This project makes that algorithm visible: it reports the LPS table, match positions, total comparisons, analyzed characters, and execution time while highlighting every result in its source text.

## Features

- Exact pattern matching using the KMP algorithm
- Linear search time: **O(N + M)**, where `N` is text length and `M` is pattern length
- Case-sensitive or case-insensitive search
- Optional overlapping-match detection
- Manual text input and multiple `.txt`, `.md`, `.csv`, or `.log` uploads
- Match location details: zero-based index, line, and column
- Highlighted source text and a clickable result list
- LPS preprocessing table for understanding the algorithm
- Comparison, character-count, match-count, and execution-time metrics
- Responsive interface for desktop and mobile

## Project structure

```text
outputs/
├── main.java    Java HTTP server, JSON handling, and KMP implementation
├── index.html   Responsive browser interface
└── README.md    Project documentation
```

## Run locally

1. Open a terminal in the folder containing these files.
2. Compile the Java source:

   ```powershell
   javac main.java
   ```

3. Start the application:

   ```powershell
   java main
   ```

4. Open [http://localhost:8080](http://localhost:8080) in a browser.
5. Stop the server with `Ctrl+C` when finished.

The project uses only the JDK's built-in HTTP server. Java 17 or newer is recommended.

## How it works

```text
Browser (index.html)
        │ sends text, pattern, and search options
        ▼
Java server (main.java)
        │ builds LPS table and runs KMP for each source
        ▼
JSON search results
        │ includes metrics, positions, and LPS values
        ▼
Dashboard renders highlights and match details
```

## Algorithm summary

For a pattern such as `ABABCABAB`, the LPS table stores how far the algorithm can safely fall back after a mismatch. During the scan, each character of the text is processed at most a small constant number of times; KMP does not rescan already-confirmed text prefixes.

| Component | Complexity |
| --- | --- |
| LPS preprocessing | O(M) time, O(M) space |
| KMP search | O(N) time |
| Total | O(N + M) time, O(M) space |

## Notes

- Files are read in the browser and sent to the local Java server only for analysis.
- An empty pattern is intentionally rejected because every position would otherwise be a match.
- The browser page must stay next to `main.java` when the server is run.
